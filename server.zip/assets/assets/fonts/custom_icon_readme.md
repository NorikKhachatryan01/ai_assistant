# Adding a Custom Icon
1. drag the config.json onto https://www.fluttericon.com/
2. then drag your new icon
3. when it appears click download
4. extract file
5. copy the config.json from the extracted file to here
6. copy the font inside the extracted fonts folder to this location and name it icons.ttf
7. Open the extracted my_flutter_app.dart file
8. Open graphics.dart and scroll to the bottom
9. Merge new icons from my_flutter_app.dart into graphics.dart
