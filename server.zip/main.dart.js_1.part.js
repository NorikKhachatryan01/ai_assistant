self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var B={
bjA(d){var x=0,w=A.u(y.d),v,u,t
var $async$bjA=A.p(function(e,f){if(e===1)return A.q(f,w)
while(true)switch(x){case 0:u=$.aik
x=3
return A.v((u==null?$.aik=$.c9E():u).vC(null,d),$async$bjA)
case 3:t=f
A.JZ(t,$.ayq(),!0)
v=new A.Xi(t)
x=1
break
case 1:return A.r(v,w)}})
return A.t($async$bjA,w)}},A
B=a.updateHolder(c[3],B)
A=c[0]
var z=a.updateTypes([])
var y={d:A.a0("Xi")}}
$__dart_deferred_initializers__["V0WaDhoQmw8eHcN5zgoT5xz7/Ew="] = $__dart_deferred_initializers__.current
