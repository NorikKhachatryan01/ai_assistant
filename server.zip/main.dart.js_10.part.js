self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var A={HQ:function HQ(d,e){this.a=d
this.b=e},a00:function a00(d){this.a=d},
a7y(d){return new A.Xq(d)},
Xq:function Xq(d){this.a=d},
Nh(d,e,f,g){Date.now()
return new A.a30(d,e,f,g)},
a30:function a30(d,e,f,g){var _=this
_.a=d
_.b=e
_.d=f
_.e=g
_.f=null},
K_:function K_(d,e){this.a=d
this.b=e},
cM:function cM(d,e){this.a=d
this.b=e}},B,C,D
A=a.updateHolder(c[18],A)
B=c[0]
C=c[2]
D=c[26]
A.HQ.prototype={
J(){return"BarcodeFormat."+this.b}}
A.a00.prototype={}
A.Xq.prototype={}
A.a30.prototype={
gb7(d){return this.a},
gGA(){return this.e},
kx(d,e){var x=this.f;(x==null?this.f=B.C(y.d,y.g):x).m(0,d,e)},
ZX(d){var x
if(d!=null){x=this.f
if(x==null)this.f=d
else x.K(0,d)}},
k(d){return this.a}}
A.K_.prototype={
J(){return"ResultMetadataType."+this.b}}
A.cM.prototype={
gbR(d){return this.a},
gcc(d){return this.b},
l(d,e){if(e==null)return!1
if(e instanceof A.cM)return this.a===e.a&&this.b===e.b
return!1},
gB(d){return 31*C.f.a_(this.a)+C.f.a_(this.b)},
k(d){return"("+B.l(this.a)+","+B.l(this.b)+")"}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inheritMany
x(B.ZQ,[A.HQ,A.K_])
x(B.Ov,[A.a00,A.Xq])
x(B.Y,[A.a30,A.cM])})()
B.a4U(b.typeUniverse,JSON.parse('{"a00":{"bb":[]},"Xq":{"bb":[]}}'))
var y={g:B.a0("Y"),d:B.a0("K_")};(function constants(){D.ec=new A.K_(11,"SYMBOLOGY_IDENTIFIER")})();(function lazyInitializers(){var x=a.lazyFinal
x($,"e8B","LQ",()=>new A.a00(null))
x($,"eaf","c4",()=>A.a7y("FormatsException"))})()}
$__dart_deferred_initializers__["n/XJJKIIdYN5Kh91xvWFBhxA7W4="] = $__dart_deferred_initializers__.current
